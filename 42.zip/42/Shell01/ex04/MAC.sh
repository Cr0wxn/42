ip link show | grep -oP '([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}'

