/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fahrakot <fahrakot@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/27 10:08:20 by fahrakot          #+#    #+#             */
/*   Updated: 2025/11/27 10:13:06 by fahrakot         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_strcmp(char *s1, char *s2)
{
    int i;

    i = 0;
    while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
        i++;
    return (s1[i] - s2[i]);
}

#include <stdio.h>
int main(void)
{
    printf("%d\n", ft_strcmp("Hello", "Hello"));   // 0
    printf("%d\n", ft_strcmp("Hello", "Hell"));    // 'o' - '\0' = 111
    printf("%d\n", ft_strcmp("Hell", "Hello"));    // '\0' - 'o' = -111
    printf("%d\n", ft_strcmp("abc", "abd"));       // 'c' - 'd' = -1
    printf("%d\n", ft_strcmp("abd", "abc"));       // 'd' - 'c' = 1
}


*****

int ft_strncmp(char *s1, char *s2, unsigned int n)
{
    unsigned int i;

    i = 0;
    if (n == 0)
        return (0);
    while (i < n && s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
        i++;
    if (i == n)
        return (0);
    return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

#include <stdio.h>

int ft_strncmp(char *s1, char *s2, unsigned int n);

int main(void)
{
    printf("%d\n", ft_strncmp("Hello", "Hello", 5));   // 0
    printf("%d\n", ft_strncmp("Hello", "Helxo", 5));   // < 0
    printf("%d\n", ft_strncmp("Hellz", "Hello", 5));   // > 0
    printf("%d\n", ft_strncmp("Hello", "Hello", 2));   // 0
    return 0;
}


********

char *ft_strcat(char *dest, char *src)
{
    int i;
    int j;

    i = 0;
    while (dest[i] != '\0')
        i++;
    j = 0;
    while (src[j] != '\0')
    {
        dest[i + j] = src[j];
        j++;
    }
    dest[i + j] = '\0';
    return (dest);
}

#include <stdio.h>

char *ft_strcat(char *dest, char *src);

int main(void)
{
    char dest[20] = "Hello ";
    char src[] = "World";

    printf("%s\n", ft_strcat(dest, src)); // Hello World
}


********************

char *ft_strncat(char *dest, char *src, unsigned int n)
{
    unsigned int i;
    unsigned int j;

    i = 0;
    while (dest[i] != '\0')
        i++;
    j = 0;
    while (src[j] != '\0' && j < n)
    {
        dest[i + j] = src[j];
        j++;
    }
    dest[i + j] = '\0';
    return (dest);
}

#include <stdio.h>

char *ft_strncat(char *dest, char *src, unsigned int nb);

int main(void)
{
    char dest[20] = "Bon";
    char src[] = "journee";

    printf("%s\n", ft_strncat(dest, src, 3)); // Bonjour
}

*************************************

unsigned int    ft_strlen(char *str)
{
    unsigned int i;

    i = 0;
    while (str[i] != '\0')
        i++;
    return (i);
}

unsigned int    ft_strlcat(char *dest, char *src, unsigned int size)
{
    unsigned int d_len;
    unsigned int s_len;
    unsigned int i;

    d_len = ft_strlen(dest);
    s_len = ft_strlen(src);

    if (size <= d_len)
        return (s_len + size);

    i = 0;
    while (src[i] != '\0' && d_len + i < size - 1)
    {
        dest[d_len + i] = src[i];
        i++;
    }
    dest[d_len + i] = '\0';
    return (d_len + s_len);
}
#include <stdio.h>

unsigned int ft_strlcat(char *dest, char *src, unsigned int size);

int main(void)
{
    char dest[20] = "Hello ";
    char src[] = "World";
    unsigned int r;

    r = ft_strlcat(dest, src, sizeof(dest));

    printf("dest = %s\n", dest); // Hello World
    printf("return = %u\n", r);  // taille totale attendue
}

