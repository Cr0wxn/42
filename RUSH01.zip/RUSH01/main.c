/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fahrakot <fahrakot@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/22 18:24:11 by fahrakot          #+#    #+#             */
/*   Updated: 2025/11/23 01:36:46 by fahrakot         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int i;
	
	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
	
}

int	ft_strlen(char *strlen)
{
	int i;

	i = 0;
	while (strlen[i] != '\0')
	{
		i++;
	}
	return(i);
}

void	ft_error(void)
{
	ft_putstr("Error\n");
}

void	ft_str_rev(char *strev)
{
	int i;

	i = ft_strlen(strev) - 1;
	while (i >= 0)
	{	
		ft_putchar(strev[i]);
		i--;
	}
}	

int	ft_checkdigi(char *str)
{
	int i;

	i = 0;

	while (str[i] != '\0')
	{
		if (str[i] == '1' || str[i] == '2' || str[i] == '3' || str[i] == '4' || str[i] == ' ' )
			i++;
		else
			return(0);
	}
	return(1);
}

int	ft_checkspace(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if(str[i + 1] == '\0')
			i++;
		else if(str[i + 1] == ' ')
			i += 2;
		else
			return(0);
	}
	return(1);
}

int	ft_checkavao(char *str)
{
	if (ft_checkdigi(str) == 1 && ft_checkspace(str) == 1 && ft_strlen(str) == 31)
		return(1);
	else
	{
		ft_error();
		return(0);
	}
}

int	main(int ac, char **av)
{
	if (ac != 2)
	{
		ft_error();
		return(0);
	}
	if (ft_checkavao(av[1]) == 0)
		return(0);
	else
	{
		ft_putstr("Mandeha eeeeee !!! \n");
	}
}
